Paste this folder in 
C:\Users\"Device_Name"\

Directory name .netbeans-derby